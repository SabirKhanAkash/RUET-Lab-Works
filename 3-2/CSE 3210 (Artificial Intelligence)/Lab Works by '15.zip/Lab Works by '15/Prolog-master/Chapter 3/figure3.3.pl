symptom(chicken_pox,high_fever).
symptom(chicken_pox,chills).
symptom(flu,chills).
symptom(cold,mild_body_ache).
symptom(flu,severe_body_ache).
symptom(cold,runny_nose).
symptom(flu,runny_nose).
symptom(flue,moderate_cough).
