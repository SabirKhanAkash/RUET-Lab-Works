# Prolog
Some solutions of Turbo Prolog book. The solutions are written in SWI Prolog.

Prolog is a general-purpose logic programming language associated with artificial intelligence and computational linguistics.
