chkstate("nc").

chkstate(_).

chkstate(State) :-
	location(State).