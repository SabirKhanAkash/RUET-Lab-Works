location(portland,or).
location(washington,dc).
location(jackson,ms).
location(meridian,ms).
location(salem,or).
