minimum(X,Y) :-
	Z is min(X,Y),
	write(Z).
