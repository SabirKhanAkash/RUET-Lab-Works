# Ask the user for a sequence then print its length

#Enter a sequence: ATTAC
#It is 5 bases long


seq = input("Enter a sequence: ")
print("It is", len(seq), "bases long")