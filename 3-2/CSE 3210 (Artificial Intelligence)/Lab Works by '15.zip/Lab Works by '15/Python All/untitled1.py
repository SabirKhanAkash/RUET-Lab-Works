# -*- coding: utf-8 -*-
"""
Created on Tue Feb  6 02:08:27 2018

@author: User
"""

import Bio