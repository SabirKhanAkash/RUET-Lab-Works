#    Modify your program from Exercise A to add three numbers.
#    Use the following as a template for your new program
#    def add3  # you must finish this line
#      # then fill in the body
#    
#    print "2+3+4 =", add(2, 3, 4)
#    print "5+9+10 =", add(5, 9, 10)


def add3(a, b, c):
    return a+b+c

print("2+3+4 =", add3(2,3,4))
print("5+9+10 =", add3(5,9,10))