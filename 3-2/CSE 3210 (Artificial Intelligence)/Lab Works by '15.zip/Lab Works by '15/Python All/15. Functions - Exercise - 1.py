#    Make a function to add two numbers.
#    Use the following as a template for your program
#    
#    def add(a, b):
#        # ... your function body goes here
#    
#    print "2+3 =", add(2, 3)
#    print "5+9 =", add(5, 9)
#    
#    The output from your program should be
#    2+3 = 5
#    5+9 = 14


def add(a, b):
    return a+b

print("2+3 =", add(2,3))
print("5+9 =", add(5,9))