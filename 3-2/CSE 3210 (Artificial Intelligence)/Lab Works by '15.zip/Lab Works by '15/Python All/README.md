# Python-Basic-Learning-Codes
<strong>Warning:</strong><br>
Don't just copy and paste. It's nothing but damaging brain cells. This repository has been made for learning purposes. As the slides contains a lot of syntax problems (as slides are in python 2), so I thought it would come handy if you are new in Python. Moreover, who wants to write such long codes which will be irritating to write once you'll learn Python a little bit.
<br>

This repository is all about basic learning with python 3. Slides and codes both has been added in this repository.<br>

And Yeah... If you find any error, do pull request for the betterment. :)
