import java.net.*;  
import java.io.*; 
import java.io.Serializable;
import java.util.*;
import java.lang.*;

class ParityObject implements Serializable
{
	int header;
	String data;
	int protocol = 10;
	int tailer;

    ParityObject(int header, String data, int protocol, int tailer)
    {
        this.header = header;
        this.data = data;
        this.protocol = protocol;
        this.tailer = tailer;
    }

	void showDetails()
	{
		System.out.println("Header was: "+header);
		System.out.println("\nEntered Data String was: "+data);
		System.out.println("\nprotocol was: "+protocol);
		System.out.println("\nTailer is: "+tailer);
		System.out.println("\nParity Matched");

	}  
}

public class MyServerClassObject
{
    public static void main(String arg[]) throws Exception
    {
       	ServerSocket server=new ServerSocket(1700);   
	    Socket s=server.accept();   
 		System.out.println("*****Connection Established*****\n");   	

		ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
		BufferedReader buffRead = new BufferedReader(new InputStreamReader(System.in));
    
    	for(int j=0; j<10 ; j++)
		{
			System.out.println("\nEnter Header and Data String respectively: \n");	
			Scanner sc = new Scanner(System.in); 
			int header = sc.nextInt();
			String data = buffRead.readLine();
			byte[] bytes = data.getBytes();
			StringBuilder binary = new StringBuilder();
			int count = 0;
			int pro = 1;
			int protocol = 10;
			int tailer = 0;

			for (byte b : bytes)
			{
				int val = b;
				for (int i = 0; i < 8; i++)
				{
					binary.append((val & 128) == 0 ? 0 : 1);
					if((val & 128) != 0)
						count++;
					val <<= 1;
				}
				binary.append(' ');
			}

			if(((pro+header+count) % 2) == 0)
				tailer += 0;
			else
				tailer += 1;



		    ParityObject object1 = new ParityObject(header,data,protocol,tailer);
		    os.writeObject(object1);
		    binary = NULL;
		   
		}
		s.close();
    }
}